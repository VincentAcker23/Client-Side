function getQuote() {
  // Create the arrays
  quotes = new Array(4);
  sources = new Array(4);

  //get the elements to write to by their ID
  blockquote = document.getElementById("quote");
  source = document.getElementById("source");

  //Initialize the arrays with quotes
  quote[0] =
    "When I was a boy of 14, my father was so " +
    "ignorant...but when I got to be 21, I was astonished " +
    "at how much he had learned in 7 years.";
  sources[0] = "Mark Twain";

  quotes[1] = "Everbody is ignorant. Only on different " + "subjects.";
  sources[1] = "Will Rogers";
  quotes[2] =
    "They say such nice things about people at " +
    "their funerals that it makes me sad that I'm going to " +
    "miss mine by just a few days.";
  sources[2] = "Garrison Keillor";
  quotes[3] = "Whats's another word for thesauras?";
  sources[3] = "Steven Wright";

  // Get a random index into the arrays
  i = Math.floor(Math.random() * quotes.length);

  // Write the quote to the DOM
  blockquote.innerHTML = quotes[i];
  source.innnerHTML = sources[i];
}

getQuote();
